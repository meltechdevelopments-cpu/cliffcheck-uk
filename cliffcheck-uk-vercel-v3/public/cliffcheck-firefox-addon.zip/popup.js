(function () {
  const cfg = window.CLIFFCHECK_CONFIG;
  const statusBox = document.getElementById("statusBox");
  const keyInput = document.getElementById("keyInput");
  const activateBtn = document.getElementById("activateBtn");
  const msg = document.getElementById("msg");
  const buyBtn = document.getElementById("buyBtn");

  buyBtn.href = cfg.checkoutUrl;

  function refreshStatus() {
    chrome.storage.local.get(["cliffcheck_pass", "cliffcheck_ext_used"], (st) => {
      statusBox.textContent = "";
      const pass = st.cliffcheck_pass;
      if (pass && pass.valid && pass.expiresAt > Date.now()) {
        const title = document.createElement("strong");
        title.style.color = "#34d399";
        title.textContent = "✅ Lifetime Pass Active";
        const br = document.createElement("br");
        const sub = document.createElement("span");
        sub.style.color = "#94a3b8";
        sub.textContent = "Unlimited AutoTrader, eBay & CarGurus checks unlocked for life.";
        statusBox.appendChild(title);
        statusBox.appendChild(br);
        statusBox.appendChild(sub);
        buyBtn.style.display = "none";
      } else {
        const left = Math.max(0, cfg.freeChecksAllowedExtension - (st.cliffcheck_ext_used || 0));
        const title = document.createElement("strong");
        title.textContent = "🎁 " + left + " Free Full Listing Check(s) Left";
        const br = document.createElement("br");
        const sub = document.createElement("span");
        sub.style.color = "#94a3b8";
        sub.textContent = "Browse any car on AutoTrader.co.uk, eBay Motors or CarGurus.co.uk to see the floating CliffCheck card.";
        statusBox.appendChild(title);
        statusBox.appendChild(br);
        statusBox.appendChild(sub);
      }
    });
  }

  refreshStatus();

  activateBtn.addEventListener("click", async () => {
    const code = keyInput.value.trim();
    if (!code) return;
    msg.textContent = "Verifying Polar Pass code...";
    msg.style.color = "#facc15";

    try {
      const result = await cfg.validatePolarKey(code);
      if (result && result.valid) {
        chrome.storage.local.set({ cliffcheck_pass: result }, () => {
          msg.style.color = "#34d399";
          msg.textContent = "✅ Pass Activated! Reload your AutoTrader tab.";
          refreshStatus();
        });
      } else {
        msg.style.color = "#f87171";
        msg.textContent = "❌ " + (result.error || "Invalid Pass code.");
      }
    } catch (e) {
      msg.style.color = "#f87171";
      msg.textContent = "Network error verifying Polar code.";
    }
  });
})();
